import { useSelector, useDispatch } from "react-redux";
import { RootState, AppDispatch } from "../store"; // Ensure correct types
import { login, logout } from "./authSlice";

const useAuthStore = () => {
  const dispatch = useDispatch<AppDispatch>(); // ✅ Ensure correct type
  const authState = useSelector((state: RootState) => state.auth);

  const loginUser = (email: string, password: string) => {
    dispatch(login({ email, password }) as any); // ✅ Fix TypeScript type issue
  };

  const logoutUser = () => {
    dispatch(logout());
  };

  return {
    ...authState,
    loginUser,
    logoutUser,
  };
};

export default useAuthStore;
